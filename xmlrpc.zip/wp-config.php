<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tlcfestival_db');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ';ixT|qNxf{N}>tNjx}]7iU1rZ&zbSZ3+VsG?2&qlC7a#WQ{&,k.J[S=x;<unM]WZ');
define('SECURE_AUTH_KEY',  '?!o7A*+n;VDmK* vie/N_RbYg79*`[4D=`Yh%$C-l[~7|?9)Z6R^#G3K~a qU/yf');
define('LOGGED_IN_KEY',    'xoB3j,mYN _?gDm5o|Ic-sBv+j~_`5,uA3rlIToZurMZlVBl7&ZVTa9| ?xWjwR:');
define('NONCE_KEY',        '%**|oke6(^U,h2f}Mx@xxtpm/@K)K%WJY zq!Ell0:(Mw?jAg|PT<Db/(2f2Z<k9');
define('AUTH_SALT',        'w4.2dgjj+BELR1]([Il]5CP.]h`:;gpdQc{]/1Jc@>D{q@M@M`zRN86<eGEzX|E;');
define('SECURE_AUTH_SALT', '9ve(D B;@.ck<[GW%~NGQ)IZgd|y=RHf, _ESGfEPgXE}0@fC}Ps2k<$P[4`Sd,9');
define('LOGGED_IN_SALT',   'k4 efoe]{U&F[;TS{$: KM<EZsncfVz|S]FfUh>C#Ou8!2.Y`b1qeynJ?{szsm)!');
define('NONCE_SALT',       'j-LTPwnR4#m,5Mn5^CUC.|V=b]P!I,1j||5t|C@0}Fkb-EIY+`dPkHrW7PRc&cru');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'tlc_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
